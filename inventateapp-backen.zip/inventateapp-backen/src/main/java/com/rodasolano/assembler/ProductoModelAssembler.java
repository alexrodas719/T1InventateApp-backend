package com.rodasolano.assembler;

import com.rodasolano.controller.ProductoController;
import com.rodasolano.dto.ProductoDTO;
import com.rodasolano.model.Producto;
import org.modelmapper.ModelMapper;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@Component
public class ProductoModelAssembler implements RepresentationModelAssembler<Producto, EntityModel<ProductoDTO>> {

    private final ModelMapper modelMapper;

    public ProductoModelAssembler(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
    }

    @Override
    public EntityModel<ProductoDTO> toModel(Producto producto) {
        ProductoDTO dto = modelMapper.map(producto, ProductoDTO.class);

        return EntityModel.of(dto,
                linkTo(methodOn(ProductoController.class).getProducto(dto.getIdProducto())).withSelfRel(),
                linkTo(methodOn(ProductoController.class).findAll()).withRel("productos"));
    }
}
