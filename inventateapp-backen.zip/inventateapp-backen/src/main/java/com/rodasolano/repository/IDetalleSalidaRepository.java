package com.rodasolano.repository;

import com.rodasolano.model.Detalle_salida;

public interface IDetalleSalidaRepository extends IGenericRepository<Detalle_salida, Integer> {

}
