package com.rodasolano.repository;

import com.rodasolano.model.Proveedor;

public interface IProveedorRepository extends IGenericRepository<Proveedor, Integer> {

}
