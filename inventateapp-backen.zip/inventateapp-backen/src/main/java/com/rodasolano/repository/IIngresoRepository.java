package com.rodasolano.repository;

import com.rodasolano.model.Ingreso;

public interface IIngresoRepository extends IGenericRepository<Ingreso, Integer> {

}
