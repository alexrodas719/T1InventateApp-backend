package com.rodasolano.repository;

import com.rodasolano.model.Producto;

public interface IProductoRepository extends IGenericRepository<Producto, Integer> {

}
