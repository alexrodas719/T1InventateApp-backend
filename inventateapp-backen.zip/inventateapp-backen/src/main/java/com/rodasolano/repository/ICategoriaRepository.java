package com.rodasolano.repository;

import com.rodasolano.model.Categoria;

public interface ICategoriaRepository extends IGenericRepository<Categoria, Integer> {

}
