package com.rodasolano.repository;

import com.rodasolano.model.Detalle_ingreso;

public interface IDetalleIngresoRepository extends IGenericRepository<Detalle_ingreso, Integer> {

}
