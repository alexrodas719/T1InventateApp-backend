package com.rodasolano.repository;

import com.rodasolano.model.Salida;

public interface ISalidaRepository extends IGenericRepository<Salida, Integer> {

}
