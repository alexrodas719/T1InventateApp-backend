package com.rodasolano.service.implementation;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import com.rodasolano.model.Ingreso;
import com.rodasolano.repository.IGenericRepository;
import com.rodasolano.repository.IIngresoRepository;
import com.rodasolano.service.IIngresoService;

@Service
@RequiredArgsConstructor
public class IngresoService extends GenericService<Ingreso, Integer> implements IIngresoService {
    private final IIngresoRepository repo;

    @Override
    protected IGenericRepository<Ingreso, Integer> getRepo(){
        return repo;
    }
}
