package com.rodasolano.service;

import com.rodasolano.model.Salida;

public interface ISalidaService extends IGenericService<Salida, Integer> {

}
