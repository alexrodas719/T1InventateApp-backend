package com.rodasolano.service;

import com.rodasolano.model.Proveedor;

public interface IProveedorService extends IGenericService<Proveedor, Integer> {

}
