package com.rodasolano.service;

import com.rodasolano.model.Ingreso;

public interface IIngresoService extends IGenericService<Ingreso, Integer> {

}
