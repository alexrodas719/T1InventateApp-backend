package com.rodasolano.service;

import com.rodasolano.model.Categoria;

public interface ICategoriaService extends IGenericService<Categoria, Integer> {

}
