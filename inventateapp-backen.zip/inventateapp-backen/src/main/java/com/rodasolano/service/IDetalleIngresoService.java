package com.rodasolano.service;

import com.rodasolano.model.Detalle_ingreso;

public interface IDetalleIngresoService extends IGenericService<Detalle_ingreso, Integer> {

}
