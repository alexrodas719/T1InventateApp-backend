package com.rodasolano.service.implementation;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import com.rodasolano.model.Proveedor;
import com.rodasolano.repository.IGenericRepository;
import com.rodasolano.repository.IProveedorRepository;
import com.rodasolano.service.IProveedorService;

@Service
@RequiredArgsConstructor
public class ProveedorService extends GenericService<Proveedor, Integer> implements IProveedorService {
    private final IProveedorRepository repo;

    @Override
    protected IGenericRepository<Proveedor, Integer> getRepo(){
        return repo;
    }
}
