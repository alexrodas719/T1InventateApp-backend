package com.rodasolano.service.implementation;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import com.rodasolano.model.Categoria;
import com.rodasolano.repository.ICategoriaRepository;
import com.rodasolano.repository.IGenericRepository;
import com.rodasolano.service.ICategoriaService;

@Service
@RequiredArgsConstructor
public class CategoriaService extends GenericService<Categoria, Integer> implements ICategoriaService {
    private final ICategoriaRepository repo;

    @Override
    protected IGenericRepository<Categoria, Integer> getRepo(){
        return repo;
    }
}
