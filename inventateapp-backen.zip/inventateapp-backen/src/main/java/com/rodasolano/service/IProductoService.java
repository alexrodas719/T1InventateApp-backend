package com.rodasolano.service;

import com.rodasolano.model.Producto;

public interface IProductoService extends IGenericService<Producto, Integer> {

}
