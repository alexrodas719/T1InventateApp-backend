package com.rodasolano.service.implementation;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import com.rodasolano.model.Detalle_salida;
import com.rodasolano.repository.IDetalleSalidaRepository;
import com.rodasolano.repository.IGenericRepository;
import com.rodasolano.service.IDetalleSalidaService;

@Service
@RequiredArgsConstructor
public class DetalleSalidaService extends GenericService<Detalle_salida, Integer> implements IDetalleSalidaService {
    private final IDetalleSalidaRepository repo;

    @Override
    protected IGenericRepository<Detalle_salida, Integer> getRepo(){
        return repo;
    }
}
