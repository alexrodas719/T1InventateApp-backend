package com.rodasolano.service.implementation;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import com.rodasolano.model.Salida;
import com.rodasolano.repository.IGenericRepository;
import com.rodasolano.repository.ISalidaRepository;
import com.rodasolano.service.ISalidaService;

@Service
@RequiredArgsConstructor
public class SalidaService extends GenericService<Salida, Integer> implements ISalidaService {
    private final ISalidaRepository repo;

    @Override
    protected IGenericRepository<Salida, Integer> getRepo(){
        return repo;
    }
}
