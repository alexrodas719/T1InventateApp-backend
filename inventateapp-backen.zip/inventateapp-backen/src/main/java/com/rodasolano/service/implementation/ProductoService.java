package com.rodasolano.service.implementation;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import com.rodasolano.model.Producto;
import com.rodasolano.repository.IGenericRepository;
import com.rodasolano.repository.IProductoRepository;
import com.rodasolano.service.IProductoService;

@Service
@RequiredArgsConstructor
public class ProductoService extends GenericService<Producto, Integer> implements IProductoService {
    private final IProductoRepository repo;

    @Override
    protected IGenericRepository<Producto, Integer> getRepo(){
        return repo;
    }
}
