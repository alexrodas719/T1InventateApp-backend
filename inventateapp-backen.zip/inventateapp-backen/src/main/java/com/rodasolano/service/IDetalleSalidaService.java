package com.rodasolano.service;

import com.rodasolano.model.Detalle_salida;

public interface IDetalleSalidaService extends IGenericService<Detalle_salida, Integer> {

}
