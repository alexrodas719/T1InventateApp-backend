package com.rodasolano.service.implementation;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import com.rodasolano.model.Detalle_ingreso;
import com.rodasolano.repository.IDetalleIngresoRepository;
import com.rodasolano.repository.IGenericRepository;
import com.rodasolano.service.IDetalleIngresoService;

@Service
@RequiredArgsConstructor
public class DetalleIngresoService extends GenericService<Detalle_ingreso, Integer> implements IDetalleIngresoService {
    private final IDetalleIngresoRepository repo;

    @Override
    protected IGenericRepository<Detalle_ingreso, Integer> getRepo(){
        return repo;
    }
}
