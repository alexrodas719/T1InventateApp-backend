package com.rodasolano;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventateappBackenApplicationTests {

	@Test
	void contextLoads() {
	}

}
